
<div class="footer">
  <p> © PRATAPbabu 2020 </p>
</div>
</div>

<script src="https://kit.fontawesome.com/ad39af6d2a.js" crossorigin="anonymous"></script>

</body>
</html>
